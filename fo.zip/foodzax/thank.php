<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank for Register with us!</title>
</head>
<body>
    <section>
        <img src="assets/images/thank.jpg" alt="Thank" class="thank-img">
        <h1 class="thank-title">Thanks for Registration!</h1>
        <p class="thanks-info">
            Thank you for registering! We appreciate your interest and are thrilled 
            to have you on board. Your registration is a valuable step towards joining 
            our community. We look forward to providing 
            you with exciting opportunities and a rewarding experience. Welcome!
        </p>

        <p class="waiting-info">
            Please wait for 1-3 days when we will approve your request you will get a congratulations
            sms from Foodzax to your provided mobile number.
        </p>
    </section>
    <style>
        body{
            font-family: 'arial';
        }
        
        section{
            width: 80%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .thank-img{
            width: 35%;
        }
        
        .thank-title{
            font-size: 45px;
            color: green;
        }
        
        .thanks-info{
            width: 80%;
            color: gray;
            text-align: center;
            font-size: 20px;
        }
        
        .waiting-info{
            font-size: 15px;
            text-align: center;
            color: green;
            width: 60%;
        }
        
        /* Responsive Styles */
        
        @media only screen and (max-width: 576px) {
            /* Styles for devices up to 576px (e.g., smartphones) */
            
            section{
                width: 90%;
            }
            .thank-img{
            width: 55%;
            }
            
            .thank-title{
                font-size: 30px;
            }
            
            .thanks-info{
                width: 100%;
                font-size: 15px;
            }
            
            .waiting-info{
                font-size: 13px;
                width: 100%;
            }
        }
        
        @media screen and (max-width: 450px) {
            /* Styles for devices between 577px and 768px (e.g., larger smartphones and small tablets) */
            
            section{
                width: 95%;
                margin-top: 10%;
            }
            .thank-img{
                width: 70%;
            }
            
            .thank-title{
                font-size: 25px;
            }
            
            .thanks-info{
                font-size: 15px;
            }
            
            .waiting-info{
                font-size: 13px;
            }
        }
        
        @media only screen and (min-width: 769px) and (max-width: 992px) {
            /* Styles for devices between 769px and 992px (e.g., tablets) */
            
            section{
                width: 75%;
            }
            
            .thank-title{
                font-size: 42px;
            }
            
            .thanks-info{
                font-size: 20px;
            }
            
            .waiting-info{
                font-size: 15px;
                width: 65%;
            }
        }
        
        @media only screen and (min-width: 993px) and (max-width: 1200px) {
            /* Styles for devices between 993px and 1200px (e.g., larger tablets) */
            
            section{
                width: 70%;
            }
            
            .thank-title{
                font-size: 44px;
            }
            
            .thanks-info{
                font-size: 21px;
            }
            
            .waiting-info{
                font-size: 16px;
                width: 60%;
            }
        }
        
        @media only screen and (min-width: 1201px) {
            /* Styles for devices larger than 1200px (e.g., desktops) */
            
            section{
                width: 60%;
            }
            
            .thank-title{
                font-size: 45px;
            }
            
            .thanks-info{
                font-size: 22px;
            }
            
            .waiting-info{
                font-size: 17px;
                width: 55%;
            }
        }
    </style>
</body>
</html>