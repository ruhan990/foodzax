<?php 
  include_once 'config.php';

// user info
if(isset($_COOKIE['you_have_logged'])){
  $user_id = $_COOKIE['you_have_logged'];
  $get_user = "SELECT * FROM users WHERE user_id = $user_id";
  $res_run = $conn->query($get_user);

if ($res_run->num_rows < 1) {
    // No rows found, cookie value is not valid
    if (isset($_COOKIE['you_have_logged'])) {
        // Delete the cookie using JavaScript
        echo '<script>document.cookie = "you_have_logged=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";</script>';
    }
    // Delay the redirection by 1 second
    echo '<script>setTimeout(function(){ window.location.href = "login.php"; }, 100);</script>';

    exit; // Stop further execution
}
}


  if(isset($_COOKIE['you_have_logged'])){
    // get user all data 
    $user_id = $_COOKIE['you_have_logged'];
    $get_user_data =  "SELECT * FROM users WHERE user_id = '$user_id'";
    $u_data_run = $conn-> query($get_user_data);
    $rows = mysqli_fetch_assoc($u_data_run);
    $user_area = $rows['area'];
  }else{
    header("Location: landing.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- meta option  -->
    <meta name="title" content="Foodzax | Be Happy on time!">
    <meta name="description" content="We serve the food that need you.">
    <meta name="keywords" content="food, foodzax, eat, bangladeshi food, food delivery">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- Add a custom icon for the shortcut -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/icons/microzax.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <!-- open graph  -->
    <meta property="og:title" content="Foodzax | It's time to Rise up!">
    <meta property="og:site_name" content="Foodzax.com">
    <meta property="og:url" content="www.foodzax.com">
    <meta property="og:description" content="We serve the food that need you.">
    <meta property="og:type" content="Online Food Service">
    <meta property="og:image" content="assets/images/logo/cover.jpg">

    <title>Foodzax | Happiness </title>
    <!-- custom css  -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- icon link  -->
    <link rel="stylesheet" href="assets/plugins/icon/css/all.css">
    <!-- slick css link  -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- preloader  -->
    <link rel="stylesheet" href="assets/css/preloader.css">
    <!-- swiper css link -->
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <!-- jquery  -->
    <script src="assets/plugins/jquery.js"></script>
</head>
<body>
    <!-- navigation  -->
    <?php include 'navigation.php'; ?>
    <!-- navigation  -->

  <!-- body part start  -->
  <section>
    <!-- feed products show  -->
    <div class="feed">
              <!-- home slider  -->
            <div id="home_header_section">
              <section class="main swiper mySwiper home-feed-swiper">
                <div class="wrapper swiper-wrapper ">
                    <?php 
                    // get banner from database
                    $get_banner =  "SELECT * FROM main_banner ORDER by id DESC";
                    $banner_run = $conn-> query($get_banner);
                    if($banner_run){
                    while($b_rows = mysqli_fetch_assoc($banner_run)){
                        echo '
                        <div class="slide swiper-slide feed-slide">
                          <a href="'.$b_rows['banner_link'].'"><img src="assets/images/logo/'.$b_rows['banner_img'].'" alt="" class="image" /></a>
                        </div>
                        ';
                        }
                    }
                    ?>
                </div>

                <div class="swiper-button-next nav-btn"></div>
                <div class="swiper-button-prev nav-btn"></div>
                <div class="swiper-pagination" style="display: flex; align-items:center;justify-content:center;"></div>
              </section>
            </div>


      <div class="feed-divided">
        <div class="product-categ-section">
              <!-- restaurant list  START -->
              <div id="feed-offered-sec">
                <div id="feed-sec-header" style="display: flex; justify-content:center; margin-bottom: 10px" >
                  <h1 id="feed-sec-right-head-title" class="mid-title-line-flex"><div class="mid-title-line"></div><span>Ajents in <b class="user-location"><?php echo $user_area; ?></b></span><div class="mid-title-line"></div></h1>
                </div>
                <div id="feed-sec-body-content">
                <?php 
                    // get restaurants from database
                    $stmt = $conn->prepare("SELECT * FROM restaurant WHERE area = '$user_area' ORDER BY id DESC LIMIT 150");
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $count_res = mysqli_num_rows($result);
                    if($count_res > 0){
                    while($rows = $result->fetch_assoc()){
                        echo '
                        <a href="product-ajent.php?res_id='.$rows['res_id'].'" id="feed-sec-prod-cart">
                          <div id="feed-prod-cart-img-holder"><img src="product-ajent/img/'.$rows['res_logo'].'" alt="Ajents image"></div>
                          <div id="feed-res-name">'.$rows['res_name'].'</div>
                        </a>
                        ';
                    }
                  }else{?>
                    <div class="empty-res">
                      <img src="assets/images/logo/empty.png" alt=""  id="empty-logo">
                      <h1 class="empty-title">আপনার এলাকার কোন এজেন্ট এখনো আমাদের তালিকা ভুক্ত নেই।</h1>
                    </div>
                    <style>
                      .empty-res{
                        display: block;
                        margin: 0 auto;
                        width: 90%;

                      }
                      #empty-logo{
                        width: 50%;
                        display: block;
                        margin: 0 auto;
                      }
                      .empty-title{
                        font-size: 17px;
                        font-weight: 500;
                        text-align: center;
                        color: #fff;
                        margin-top: -2%;
                        margin-bottom: 15px;
                      }
                    </style>
                  <?php } ?>

                </div>
              </div>
          </div>
      </div>
    </div>
  </section>

  <?php include 'footer.php' ?>


<!-- Swiper JS -->
<script src="assets/js/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>

  var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    loop: true,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1000,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

  // page loader
  window.addEventListener("load", function(){
        const loader = document.getElementById("loader");
        loader.style.display = "none";
        document.body.classList.remove("loading");
      });
      
      document.body.classList.add("loading");
    // page loader 
      
    // category collapsible 
    $(document).ready(function() {
  $('.category-heading').click(function() {
    $(this).next('.child-categories').toggle();
  });
  });
</script>
  <script type="text/javascript" src="assets/plugins/slick.min.js"></script>
  <script  src="assets/js/script.js"></script>
</body>
</html>