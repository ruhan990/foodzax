<nav>
  <!-- category activation function  -->
    <?php

    // count my orders 
    if(isset($_COOKIE['you_have_logged'])){
      $user_id = $_COOKIE['you_have_logged'];
      
      $count_order =  "SELECT * FROM orders WHERE (activity != 'delivered' AND activity != 'return') AND customer_id = '$user_id' ";
      $oc_run = $conn-> query($count_order);
      $total_orders = mysqli_num_rows($oc_run);
      if($total_orders > 99){
        $total_orders = '99+';
      }
      if($total_orders > 0){
        $order_count_past = '<span id="count-alt">'.$total_orders.'</span>';
      }else{
        $order_count_past = '';
      }

      // count mail 
      $count_mail =  "SELECT * FROM mail WHERE (send_to = '$user_id' AND status = 'unseen') OR  (send_to = 'all')";
      $mc_run = $conn-> query($count_mail);
      $total_mail = mysqli_num_rows($mc_run);
      if($total_mail > 99){
        $total_mail = '99+';
      }
      if($total_mail > 0){
        $mail_count_past = '<span id="count-alt">'.$total_mail.'</span>';
      }else{
        $mail_count_past = '';
      }
    }else{
      $user_id = '';
      $order_count_past = '';
      $mail_count_past = '';
  }
  ?>
  <!-- category activation function  -->
  
  
      <div class="nav-home">
          <!-- logo and 2 menu  -->
          <div class="logo-holder">
          <!-- <i class="fas fa-bars" title="All Categories" id="main_categ_list_menu"></i> -->
          <i class="fas fa-times" title="Category Close" id="main_categ_list_menu_close" style="display: none;"></i>
          <a href="./"><img src="assets/images/logo/foodzax.png" alt="foodzax" class="main-logo"></a>
          </div>

          <!-- search bar  -->
          <form action="68607/action/main-search.php" method="POST" class="search-section">
            <input type="text" name="key" value="" placeholder="Find a nearest restaurant..." autocomplete="off" dir="auto" tabindex="0" aria-label="Search" class="search-box">
            <button class="search-btn"><i class="fas fa-search"></i></button>
          </form>

          <!-- menu list  -->
          <div class="menu-section">
            <a href="https://web.facebook.com/profile.php?id=100093630251039&_rdc=1&_rdr" class="home-tabs" title="Business News Feed"><i class="fab fa-facebook"></i></a>
            <a href="profile/" class="home-tabs"><i class="fas fa-user-circle" title="Profile"></i></a>
            <a href="profile/" class="home-tabs" title="Announcement"><i class="fas fa-envelope"></i></a>
            <a href="profile/?tab=myorder" class="home-tabs" title="Your Orders"><i class="fas fa-shopping-cart"></i> <?php echo $order_count_past; ?></a>
          </div>
      </div>
    </nav>


      