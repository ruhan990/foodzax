<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Join on Foodzax as a Partner</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="rider/all-style/register.css"/>
    <link rel="stylesheet" href="assets/plugins/icon/css/all.css">
</head>
<body>
    <div class="main">
        <div class="container">
            <div class="signup-content">
                <div class="signup-img">
                    <img src="assets/images/restaurant join.jpg" alt="">
                </div>
                <div class="signup-form">
                <form action="product-ajent/action/new-restaurant.php" method="POST" class="register-form" id="register-form" enctype="multipart/form-data">
                    <h2>Grow your business today with Foodzax</h2>
                    <p>আপনার এজেন্টের প্রোডাক্ট  বিক্রি করার জন্য আমাদের সাথে যোগদান করুন। আমাদের ওয়েবসাইটে অনলাইনে অর্ডার দিতে আপনার এজেন্টকে  প্রমোট করব। আমাদের সাথে যোগদান করতে নিচের তথ্য গুলো দিয়ে জয়েন করুন।</p>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="res_name">Ajent Name:</label>
                            <input type="text" name="res_name" id="res_name" maxlength="20" required placeholder="e.g Product Ajent"/>
                        </div>
                        <div class="form-group">
                            <label for="contact_number">Help/Contact Number:</label>
                            <input type="text" name="contact_number" id="contact_number"  maxlength="14" required placeholder="Mobile number"/>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="facebook_id">Facebook Page:</label>
                            <input type="text" name="facebook_id" id="facebook_id" required maxlength="120" placeholder="www.facebook.com/Product-Ajent"/>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="text" name="email" id="email" maxlength="35" required placeholder="productajent@gmail.com"/>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="zilla">Ajent Zilla:</label>
                            <div class="form-select">
                                <select name="zilla" id="zilla" required>
                                    <option value="">Select District/Zilla</option>
                                    <?php 
                                    // get all zilla
                                    $get_zilla = "SELECT * FROM zilla";
                                    $zilla_run = $conn->query($get_zilla);
                                    if ($zilla_run) {
                                        while ($rows = mysqli_fetch_assoc($zilla_run)) {
                                            echo '<option value="'.$rows['zilla_id'].'">'.$rows['zilla_name'].'</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="area">Ajent Area/Union:</label>
                            <div class="form-select">
                                <select name="area" id="area" required>
                                    <option value="">Area/Union</option>
                                    <?php 
                                    // get all area
                                    $get_area = "SELECT * FROM area";
                                    $area_run = $conn->query($get_area);
                                    if ($area_run) {
                                        while ($rows = mysqli_fetch_assoc($area_run)) {
                                            echo '<option value="'.$rows['area_id'].'">'.$rows['area_name'].'</option>';
                                        }
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="address">Ajent Full Address:</label>
                        <input type="text" name="address" id="address" maxlength="60" required/>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="open_time">Ajent Open time:</label>
                            <input type="text" name="open_time" id="open_time" maxlength="10" required placeholder="08:30 AM" required/>
                        </div>
                        <div class="form-group">
                            <label for="close_time">Ajent Close time:</label>
                            <input type="text" name="close_time" id="close_time" required maxlength="10" placeholder="10:00 PM" required />
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="found_date">Ajent founded date:</label>
                            <input type="text" name="found_date" id="found_date" required placeholder="DD-MM-YYYY" required>
                        </div>
                        <div class="form-group">
                            <label for="founder_name">Founder Name:</label>
                            <input type="text" name="founder_name" id="founder_name" required placeholder="Ajent holder's name">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="founder_mobile">Founder mobile:</label>
                            <input type="text" name="founder_mobile" id="founder_mobile" required placeholder="017XXX-XXXXX">
                        </div>
                        <div class="form-group">
                            <label for="founder_address">Founder Address:</label>
                            <input type="text" name="founder_address" id="founder_address" required placeholder="Ajent holder's address">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="payment_method">Payment Method:</label>
                            <div class="form-select">
                                <select name="payment_method" id="payment_method" required>
                                    <option value="bKash" selected>bKash</option>
                                    <option value="Nagad">Nagad</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="account_no">Account No:</label>
                            <input type="text" name="account_no" id="account_no" required placeholder="Selected Account No." />
                        </div>
                    </div>
                    <div class="form-radio">
                        <label for="gender" class="radio-label">Your Gender:</label>
                        <div class="form-radio-item">
                            <input type="radio" name="gender" value="Male" id="male" checked>
                            <label for="male">Male</label>
                            <span class="check"></span>
                        </div>
                        <div class="form-radio-item">
                            <input type="radio" name="gender" value="Female" id="female">
                            <label for="female">Female</label>
                            <span class="check"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password">New Password:</label>
                        <input type="text" name="password" id="password" required />
                    </div>
                    <div class="form-group">
                        <label for="image">Ajent Logo/Photo:</label>
                        <input type="file" name="res_logo" id="image" required />
                    </div>
                    <p>By clicking "Submit" you agree with our <a href="rules/terms and conditions.php">Terms and Conditions</a> and <a href="rules/privacy and policy.php">Privacy and Policy</a> to join as a rider on Foodzax.</p>
                    <div class="form-submit">
                        <input type="submit" value="Reset All" class="submit" name="reset" id="reset" />
                        <input type="submit" value="Submit Form" class="submit" name="submit" id="submit" />
                    </div>
                </form>
                </div>
            </div>
        </div>

    </div>
	<script src="../assets/plugins/jquery.js"></script>
	<script src="js/jquery.steps.js"></script>
	<script src="js/main.js"></script>
</body>
</html>