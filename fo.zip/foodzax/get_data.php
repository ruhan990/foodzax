<?php 
// connect to the database
$conn = mysqli_connect("localhost", "root", "", "microzax");

// select the product_title from the database
$result = mysqli_query($conn, "SELECT product_title FROM products");

// create an array to hold the data
$data = array();

// loop through the result set and add each row to the array
while ($row = mysqli_fetch_assoc($result)) {
  $data[] = $row['product_title']. '<br>'.'';
}

// encode the array as JSON and send it as the response
echo json_encode($product_title);
?>