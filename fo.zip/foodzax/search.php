<?php include_once 'config.php'; ?>
<?php if(isset($_GET['key'])){
   $keyword = mysqli_real_escape_string($conn, htmlentities($_GET['key']));
}

    $user_id = $_COOKIE['you_have_logged'];
    $get_user_data =  "SELECT * FROM users WHERE user_id = '$user_id'";
    $u_data_run = $conn-> query($get_user_data);
    $rows = mysqli_fetch_assoc($u_data_run);
    $user_area = $rows['area'];
?>
<!DOCTYPE html>
<html lang="en">
<head>  
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search: <?php echo $keyword; ?> </title>
    <!-- style link  -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="assets/css/search.css"> -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- icon link  -->
  <link rel="stylesheet" href="assets/plugins/icon/css/all.css">
  <!-- jquery  -->
  <script src="assets/plugins/jquery.js"></script>
</head>
<body>
    <!-- navigation  -->
    <?php include 'navigation.php'; ?>

    <section>
    <!-- feed products show  -->
    <div class="feed categ-feed">
        <!-- sub categ  -->
        <h1 class="menu-title" style="color: #fff;font-weight:500;">Result of <b><?php echo $keyword; ?></b> listed</h1>
        <!-- sub categ  -->

        <!-- feed products by category -->
        <div class="product-categ-section categ-feed-product-list">
          <!-- here will append the result  -->
            <div class="in-sec-products-list">
                <?php 
                    // get restaurant 
                    $get_restaurant =  "SELECT * FROM restaurant WHERE area = '$user_area' AND res_name LIKE '%$keyword%' LIMIT 50";
                    $gp_run = $conn-> query($get_restaurant);
                    if(mysqli_num_rows($gp_run) > 0){
                    while($rows = mysqli_fetch_assoc($gp_run)){
                        $res_id = $rows['res_id'];
                        // 
                        echo '
                        <a href="restaurant.php?res_id='.$rows['res_id'].'" class="feed-product">
                            <div class="feed-thumb-holder">
                            <img src="restaurant/img/'.$rows['res_logo'].'" alt="Restaurant Logo">
                            </div>
                            <h1 class="feed-product-title" style="text-align:center;">'.$rows['res_name'].'</h1>
                        </a>
                        ';
                        }
                    }
                ?>
            </div>
        </div>
      </div>
</section>
<script src="assets/js/script.js"></script>
</body>
</html>