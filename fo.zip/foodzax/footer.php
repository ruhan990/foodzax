<footer>
    <div class="content">
      <div class="top">
        <div class="logo-details">
          <span class="logo_name"><img src="assets/images/logo/foodzax.png" alt=""></span>
        </div>
      </div>
      <div class="link-boxes">
        <ul class="box">
          <li class="link_name">Company</li>
          <li><a href="./">Home</a></li>
          <li><a href="rules/contact us.php">Contact us</a></li>
          <li><a href="rules/privacy and policy.php">Privacy and Policy</a></li>
          <li><a href="rules/terms and conditions.php">Terms and Conditions</a></li>
        </ul>
        <ul class="box">
          <li class="link_name">Services</li>
          <li><a>Find restaurant</a></li>
          <li><a>Best quality food</a></li>
          <li><a>Fast delivery</a></li>
          <li><a href="foodzax.apk">Download Foodzax App</a></li>
        </ul>
        <ul class="box">
          <li class="link_name">My Account</li>
          <li><a href="profile/">Profile</a></li>
          <li><a href="profile/">Messages</a></li>
          <li><a href="profile/?tab=myorder">My orders</a></li>
          <li><a href="profile/?tab=delivered">Delivered</a></li>
        </ul>
        <ul class="box">
          <li class="link_name">Earn by Foodzax</li>
          <li><a href="rider/">Login Rider</a></li>
          <li><a href="restaurant/">Login Product Ajent</a></li>
          <li><a href="rider/register.php">Register New Rider</a></li>
          <li><a href="join-restaurant.php">Register New Product Ajent</a></li>
          
        </ul>
        
      </div>
    </div>
    <div class="bottom-details">
      <div class="bottom_text">
        <span class="copyright_text">Copyright © 2023 Foodzax.com All rights reserved</span>
        <span class="policy_terms">
          <a href="www.microzax.com" hidden>Microzax</a>
          <a href="www.farmzax.com" hidden>Farmzax</a>
          <a href="https://www.facebook.com/profile.php?id=100084765961300">Developed by Rony </a>
        </span>
      </div>
    </div>
  </footer>