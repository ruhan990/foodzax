-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2023 at 07:57 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodzax`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminzax`
--

CREATE TABLE `adminzax` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `facebook` text NOT NULL,
  `phone` text NOT NULL,
  `commission` varchar(200) NOT NULL,
  `delivery_charge` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminzax`
--

INSERT INTO `adminzax` (`id`, `email`, `pass`, `facebook`, `phone`, `commission`, `delivery_charge`) VALUES
(1, 'adminzax@foodzax.com', 'adminzax@foodzax.com', 'https://web.facebook.com/profile.php?id=100093630251039&_rdc=1&_rdr', '+880 1977 691312', '20', '40');

-- --------------------------------------------------------

--
-- Table structure for table `all_terms`
--

CREATE TABLE `all_terms` (
  `id` int(11) NOT NULL,
  `terms` longtext NOT NULL,
  `privacy` longtext NOT NULL,
  `contact` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `all_terms`
--

INSERT INTO `all_terms` (`id`, `terms`, `privacy`, `contact`) VALUES
(2, 'terms', '<p><strong>privacy <br /></strong></p>', 'contact');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `id` int(11) NOT NULL,
  `area_id` varchar(150) NOT NULL,
  `area_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id`, `area_id`, `area_name`) VALUES
(6, 'Baghutia', 'Baghutia'),
(7, 'Prembag', 'Prembag'),
(8, 'Sundoli', 'Sundoli'),
(9, 'Payra', 'Payra'),
(10, 'Chalishia', 'Chalishia'),
(11, 'Siddhipasha', 'Siddhipasha'),
(12, 'Sreedharpur', 'Sreedharpur'),
(13, 'Suvorara', 'Suvorara'),
(14, 'Basuari', 'Basuari'),
(15, 'Bandabila', 'Bandabila'),
(16, 'Darajhat', 'Darajhat'),
(17, 'Dhalgram', 'Dhalgram'),
(18, 'Dohakula', 'Dohakula'),
(19, 'Jamdia', 'Jamdia'),
(20, 'Jahurpur', 'Jahurpur'),
(21, 'Narikelbaria', 'Narikelbaria'),
(22, 'Roypur', 'Roypur'),
(23, 'Chowgacha', 'Chowgacha'),
(24, 'Dhuliani', 'Dhuliani'),
(25, 'Hakimpur', 'Hakimpur'),
(26, 'Jagadishpur', 'Jagadishpur'),
(27, 'Swarupdaha', 'Swarupdaha'),
(28, 'Narayanpur', 'Narayanpur'),
(29, 'Pashapole', 'Pashapole'),
(30, 'Patibila', 'Patibila'),
(31, 'Phulsara', 'Phulsara'),
(32, 'Singhajhuli', 'Singhajhuli'),
(33, 'Sukpukuria', 'Sukpukuria'),
(34, 'Bankura', 'Bankura'),
(35, 'Ganganandapur', 'Ganganandapur'),
(36, 'Gadkhali', 'Gadkhali'),
(37, 'Hajirbag', 'Hajirbag'),
(38, 'Jhikargachha', 'Jhikargachha'),
(39, 'Magura', 'Magura'),
(40, 'Navaron', 'Navaron'),
(41, 'Nirbaskhola', 'Nirbaskhola'),
(42, 'Panisara', 'Panisara'),
(43, 'Shankarpur', 'Shankarpur'),
(44, 'Shimulia', 'Shimulia'),
(45, 'Bidyanandakati', 'Bidyanandakati'),
(46, 'Gourighona', 'Gourighona'),
(47, 'Keshabpur', 'Keshabpur'),
(48, 'Majidpur', 'Majidpur'),
(49, 'Mangalkot', 'Mangalkot'),
(50, 'Panjia', 'Panjia'),
(51, 'Sagardari', 'Sagardari'),
(52, 'Sufalakati', 'Sufalakati'),
(53, 'Trimohini', 'Trimohini'),
(54, 'Arabpur', 'Arabpur'),
(55, 'Basundia', 'Basundia'),
(56, 'Chanchra', 'Chanchra'),
(57, 'Churamonkati', 'Churamonkati'),
(58, 'Deara', 'Deara'),
(59, 'Fatepur', 'Fatepur'),
(60, 'Hoibatpur', 'Hoibatpur'),
(61, 'Ehali', 'Ehali'),
(62, 'Kashimpur', 'Kashimpur'),
(63, 'Kachua', 'Kachua'),
(64, 'Lebutala', 'Lebutala'),
(65, 'Narendrapur', 'Narendrapur'),
(66, 'Noapara', 'Noapara'),
(67, 'Ramnagar', 'Ramnagar'),
(68, 'Bhojgati', 'Bhojgati'),
(69, 'Chaluahati', 'Chaluahati'),
(70, 'Dhakuria', 'Dhakuria'),
(71, 'Durbadanga', 'Durbadanga'),
(72, 'Haridaskati', 'Haridaskati'),
(73, 'Hariharnagar', 'Hariharnagar'),
(74, 'Jhapa', 'Jhapa'),
(75, 'Kashimnagar', 'Kashimnagar'),
(76, 'Khanpur', 'Khanpur'),
(77, 'Khedapara', 'Khedapara'),
(78, 'Kultia', 'Kultia'),
(79, 'Monirampur', 'Monirampur'),
(80, 'Manoharpur', 'Manoharpur'),
(81, 'Maswimnagar', 'Maswimnagar'),
(82, 'Nehalpur', 'Nehalpur'),
(83, 'Rohita', 'Rohita'),
(84, 'Shyamkur', 'Shyamkur'),
(85, 'Bagachra', 'Bagachra'),
(86, 'Bahadurpur', 'Bahadurpur'),
(87, 'Benapole', 'Benapole'),
(88, 'Dihi', 'Dihi'),
(89, 'Goga', 'Goga'),
(90, 'Kayba', 'Kayba'),
(91, 'Laxmanpur', 'Laxmanpur'),
(92, 'Nizampur', 'Nizampur'),
(93, 'Putkhali', 'Putkhali'),
(94, 'Sharsha', 'Sharsha'),
(95, 'Ulshi', 'Ulshi');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `rider_id` varchar(120) NOT NULL,
  `admin_id` varchar(20) NOT NULL DEFAULT 'admin',
  `messages` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE `mail` (
  `id` int(11) NOT NULL,
  `send_to` text NOT NULL,
  `thumbnail` varchar(150) NOT NULL,
  `mail_title` varchar(255) NOT NULL,
  `mail_body` longtext NOT NULL,
  `status` varchar(22) NOT NULL DEFAULT 'unseen',
  `created` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `main_banner`
--

CREATE TABLE `main_banner` (
  `id` int(11) NOT NULL,
  `banner_img` varchar(255) NOT NULL,
  `banner_link` varchar(255) NOT NULL,
  `created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_banner`
--

INSERT INTO `main_banner` (`id`, `banner_img`, `banner_link`, `created`) VALUES
(44, '1687263541.jpg', '', '20-06-2023'),
(45, '1687263545.jpg', '', '20-06-2023'),
(46, '1687263548.jpg', '', '20-06-2023'),
(47, '1687263552.jpg', '', '20-06-2023');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `incoming_msg_id` int(250) NOT NULL,
  `outgoing_msg_id` int(250) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `iv` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE `offer` (
  `id` int(11) NOT NULL,
  `product_code` varchar(150) NOT NULL,
  `offer_price` int(20) NOT NULL,
  `pre_price` int(20) NOT NULL,
  `res_id` text NOT NULL,
  `created` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`id`, `product_code`, `offer_price`, `pre_price`, `res_id`, `created`) VALUES
(90, '1687354142', 100, 434, '613135', '21 Jun 2023');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` text NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_code` text NOT NULL,
  `food_name` text NOT NULL,
  `food_price` text NOT NULL,
  `food_img` varchar(250) NOT NULL,
  `cus_name` text NOT NULL,
  `cus_mobile` text NOT NULL,
  `cus_address` text NOT NULL,
  `method` text NOT NULL,
  `qnty_type` text NOT NULL,
  `qnty` text NOT NULL,
  `activity` varchar(50) NOT NULL DEFAULT 'store',
  `status` varchar(255) NOT NULL,
  `total_bill` text NOT NULL,
  `delivered` varchar(120) NOT NULL,
  `rider_id` text NOT NULL,
  `res_id` text NOT NULL,
  `ordered` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_name` text NOT NULL,
  `sell_price` int(150) NOT NULL,
  `qnty_type` text NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `sold` varchar(230) NOT NULL,
  `res_id` text NOT NULL,
  `created` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `id` int(11) NOT NULL,
  `res_id` varchar(200) NOT NULL,
  `pass` text NOT NULL,
  `res_name` text NOT NULL,
  `contact_number` text NOT NULL,
  `facebook_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `open_time` text NOT NULL,
  `close_time` text NOT NULL,
  `found_date` text NOT NULL,
  `founder_name` text NOT NULL,
  `founder_mobile` text NOT NULL,
  `founder_address` text NOT NULL,
  `account_no` text NOT NULL,
  `payment_method` text NOT NULL,
  `zilla` text NOT NULL,
  `area` text NOT NULL,
  `gender` text NOT NULL,
  `rider_id` varchar(120) NOT NULL,
  `balance` int(10) NOT NULL,
  `res_logo` varchar(350) NOT NULL,
  `acc_status` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rider_info`
--

CREATE TABLE `rider_info` (
  `id` int(11) NOT NULL,
  `rider_id` varchar(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` text NOT NULL,
  `pass` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` text NOT NULL,
  `zilla` text NOT NULL,
  `area` text NOT NULL,
  `birth_date` varchar(100) NOT NULL,
  `r_p_method` text NOT NULL,
  `account` text NOT NULL,
  `rider_of` text NOT NULL,
  `balance` text NOT NULL DEFAULT '0',
  `rider_img` varchar(320) NOT NULL,
  `document` varchar(250) NOT NULL,
  `status` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `submit_payment`
--

CREATE TABLE `submit_payment` (
  `id` int(11) NOT NULL,
  `rider_id` text NOT NULL,
  `rider_name` text NOT NULL,
  `method` text NOT NULL,
  `acc_no` text NOT NULL,
  `amount` varchar(250) NOT NULL,
  `tranxId` varchar(200) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `product_code` text NOT NULL,
  `res_id` text NOT NULL,
  `user_id` text NOT NULL,
  `total_bill` int(11) NOT NULL,
  `activity` text NOT NULL,
  `delivery_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `chanel_type` text NOT NULL,
  `chanel_id` text NOT NULL,
  `method` text NOT NULL,
  `account` text NOT NULL,
  `amount` text NOT NULL,
  `trnxId` text NOT NULL,
  `date` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` text NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `orders` int(11) NOT NULL,
  `delivered` int(11) NOT NULL,
  `district` text NOT NULL,
  `area` text NOT NULL,
  `home_road` text NOT NULL,
  `joined` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_request`
--

CREATE TABLE `withdraw_request` (
  `id` int(11) NOT NULL,
  `client_name` text NOT NULL,
  `method` text NOT NULL,
  `acc_no` text NOT NULL,
  `amount` varchar(250) NOT NULL,
  `req_date` varchar(200) NOT NULL,
  `current_balance` varchar(200) NOT NULL,
  `chanel_type` text NOT NULL,
  `chanel_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zilla`
--

CREATE TABLE `zilla` (
  `1` int(11) NOT NULL,
  `zilla_id` varchar(150) NOT NULL,
  `zilla_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `zilla`
--

INSERT INTO `zilla` (`1`, `zilla_id`, `zilla_name`) VALUES
(4, 'Jessore', 'Jessore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminzax`
--
ALTER TABLE `adminzax`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `all_terms`
--
ALTER TABLE `all_terms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_banner`
--
ALTER TABLE `main_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rider_info`
--
ALTER TABLE `rider_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submit_payment`
--
ALTER TABLE `submit_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_request`
--
ALTER TABLE `withdraw_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zilla`
--
ALTER TABLE `zilla`
  ADD PRIMARY KEY (`1`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_terms`
--
ALTER TABLE `all_terms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `main_banner`
--
ALTER TABLE `main_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=862;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `rider_info`
--
ALTER TABLE `rider_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `submit_payment`
--
ALTER TABLE `submit_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2934;

--
-- AUTO_INCREMENT for table `withdraw_request`
--
ALTER TABLE `withdraw_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `zilla`
--
ALTER TABLE `zilla`
  MODIFY `1` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
