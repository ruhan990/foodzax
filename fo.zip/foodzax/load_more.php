        <?php 
        include_once 'config.php';
        // Default value 
        $categ_name = $_POST['categ_name'];
        $page = $_POST['page']??1;
        $limit = 15;
        $row = ($page - 1) * $limit;

              $get_new_product =  "SELECT * FROM products WHERE category = '$categ_name' AND stock = 'Available' ORDER by id DESC LIMIT $row,$limit";
              $new_p_run = $conn-> query($get_new_product);
              if(mysqli_num_rows($new_p_run) > 0){
              while($np_rows = mysqli_fetch_assoc($new_p_run)){
                $product_code = $np_rows['product_code'];
                
                // Get product image 
                $get_new_product_img =  "SELECT * FROM product_photos WHERE product_code = '$product_code'";
                $new_pi_run = $conn-> query($get_new_product_img);
                $pi_rows = mysqli_fetch_assoc($new_pi_run);
                $product_img = $pi_rows['images'];

                echo '
                  <a href="product.php?p='.$np_rows['product_code'].'" class="feed-product">
                    <div class="feed-thumb-holder">
                      <img src="assets/images/products/'.$product_img.'" alt="">
                    </div>
                    <p class="product-price"><span>Tk.'.$np_rows['sell_price'].' </span> <span id="feed-prod-rev"><i class="fas fa-star"></i> '.$np_rows['reviews'].' </span> </p>
                    <div id="feed-prod-cart-title"><img src="assets/images/icons/china.png" alt="Ship from china microzax" > Made in China</div>
                    <div id="feed-prod-cart-title"><img src="assets/images/icons/shipping.png" alt="Delivery time microzax" > Shipping from China</div>
                  </a>';
                }
              }
        ?>