<?php  include_once 'config.php'; ?>
<?php 
    // get restaurants from database
    if(isset($_GET['res_id'])){
        $res_id = $_GET['res_id'];
    }else{
        header('Location: index.php');
    }
    $stmt = $conn->prepare("SELECT * FROM restaurant WHERE res_id = $res_id ORDER BY id DESC LIMIT 35");
    $stmt->execute();
    $result = $stmt->get_result();
     
    $rows = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $rows['res_name']; ?></title>
    <meta name="title" content="Restaurant Name">
    <meta name="description" content="We serve the food that need you.">
    <meta name="keywords" content="food, foodzax, eat, bangladeshi food, food delivery">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="assets/css/restaurant.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- icon link  -->
    <link rel="stylesheet" href="assets/plugins/icon/css/all.css">
    <!-- jquery  -->
    <script src="assets/plugins/jquery.js"></script>
</head>
<body>
    <?php include 'navigation.php' ?>

   
    
    <div class="feed categ-feed">
        <!-- sub categ  -->
        <div id="feed-sec-header" style="display: flex; justify-content:center; margin-bottom: 10px" >
            <h1 id="feed-sec-right-head-title" class="mid-title-line-flex"><div class="mid-title-line"></div><span>Menu Products <b class="user-location">Listed</b></span><div class="mid-title-line"></div></h1>
        </div>
        <!-- sub categ  -->

        <!-- feed products by category -->
        <div class="product-categ-section categ-feed-product-list">
          <!-- here will append the result  -->
            <div class="in-sec-products-list load_categ_data">
                <?php 
                    // get products from database
                    $get_product = $conn->prepare("SELECT * FROM products WHERE res_id = $res_id ORDER BY id DESC LIMIT 35");
                    $get_product->execute();
                    $p_result = $get_product->get_result();
                    
                    while($rows = $p_result->fetch_assoc()){
                        $product_price = $rows['sell_price']; 
                        $product_code = $rows['product_code'];
                        $get_offer = $conn->prepare("SELECT * FROM offer WHERE product_code = ?");
                        $get_offer->bind_param("s", $product_code);
                        $get_offer->execute();
                        $o_result = $get_offer->get_result();
                        $o_rows = $o_result->fetch_assoc();

                        if ($o_rows !== null && $product_code == $o_rows['product_code']) {
                            $offer = '<span class="offer_tag"><del>Tk.'.$o_rows["pre_price"].'</del></span>';
                            $product_price = $o_rows['offer_price'];
                        } else {
                            $offer = '';
                            $product_price = $product_price;
                        }
                        ?>
                        <div class="feed-product">
                            <div class="feed-thumb-holder">
                                <?php echo $offer; ?>
                                <img src="product-ajent/img/<?php echo $rows['image']; ?>" alt="<?php echo $rows['product_name']; ?>">
                            </div>
                            <p class="product-price"><span>Tk.<?php echo $product_price; ?> </span> <span id="feed-prod-rev">/<?php echo $rows['qnty_type']; ?> </span> </p>
                            <div id="feed-prod-cart-title"><?php echo $rows['product_name']; ?></div>
                            <a href="product-ajent.php?res_id=<?php echo $res_id; ?>&food_id=<?php echo $rows['product_code']; ?>"><button id="food-order-btn"><i class="fas fa-shopping-cart"></i> Order Now</button></a>
                        </div>
                        <style>
                            .offer_tag{
                                position: absolute;
                                border-radius: 3px;
                                padding: 2px 6px;
                                margin: 3px;
                                color: red;
                                background: #fff;
                                font-size: 13px;
                            }
                        </style>
                        <?php
                    }
                ?>
                
            </div>
            <!-- <img src="assets/images/icons/loader.gif" alt="Loading..." id="categ_product_loader"> -->
        </div>

        <?php 
        if(isset($_GET['food_id'])){ 
            // get products from database
            $food_id = $_GET['food_id'];
            $get_product = $conn->prepare("SELECT * FROM products WHERE product_code = $food_id");
            $get_product->execute();
            $p_result = $get_product->get_result();
            $rows = $p_result->fetch_assoc();

            $food_name = $rows['product_name'];
            $food_price = $rows['sell_price'];
            $qnty_type = $rows['qnty_type'];
            $food_img = $rows['image'];
            $res_id = $rows['res_id'];

            // get users from database
            $user_id = $_COOKIE['you_have_logged'];
            $get_users = $conn->prepare("SELECT * FROM users WHERE user_id = $user_id");
            $get_users->execute();
            $u_result = $get_users->get_result();
            $u_rows = $u_result->fetch_assoc();
            
            $username = $u_rows['full_name'];
            $user_mobile = $u_rows['mobile'];
            $user_zilla = $u_rows['district'];
            $user_area = $u_rows['area'];
            $u_address = $u_rows['home_road'];
            $full_address = $user_zilla . ' ' . $user_area . ' ' . $u_address;
            ?>
            
            <div class="order-form-popup">
                <form action="product-ajent/action/new-order.php" method="POST">
                    <div class="delivery-info">
                        <h1 class="info-sec-title header-close-holder">Delivery Information</h1>
                            <label>Name:</label><br>
                            <input type="text" name="cus_name" value="<?php echo $username; ?>" placeholder="Enter your name" class="inp_box"><br>
                            <label>Mobile:</label><br>
                            <input type="text" name="cus_mobile" value="<?php echo $user_mobile; ?>" placeholder="017XXXXXXXXXX" class="inp_box"><br>
                            <label>Home Address:</label><br>
                            <textarea name="cus_address" id="address-box" placeholder="e.g Beside bus stop. 2/27 House no 45 and flor no 5 left."><?php echo $full_address; ?></textarea>
                            <br>

                            <!-- additional info  -->
                            <input type="text" name="food_name" value="<?php echo $food_name; ?>" hidden>
                            <input type="text" name="food_price" value="<?php echo $food_price; ?>" hidden>
                            <input type="text" name="qnty_type" value="<?php echo $qnty_type; ?>" hidden>
                            <input type="text" name="food_img" value="<?php echo $food_img; ?>" hidden>
                            <input type="text" name="customer_id" value="<?php echo $_COOKIE['you_have_logged']; ?>" hidden>
                            <input type="text" name="res_id" value="<?php echo $res_id; ?>" hidden>
                            <input type="text" name="food_id" value="<?php echo $food_id; ?>" hidden>
                    </div>
                    <div class="payment-info">
                        <h1 class="info-sec-title header-close-holder">Payment Information <a href="product-ajent.php?res_id=<?php echo $res_id; ?>"><i class="fas fa-times"></i></a></h1>
                        <table>
                            <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Value</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>Payment method:</td>
                                <td><select name="method" id="t_select_payment">
                                    <option value="Cash On Delivery">Cash On Delivery</option>
                                </select></td>
                            </tr>
                            <tr>
                                <td>Food Name:</td>
                                <td><?php echo $food_name; ?></td>
                            </tr>
                            <tr>
                                <td>Price:</td>
                                <td>৳.<?php echo $food_price; ?></td>
                            </tr>
                            <tr>
                                <td>Qnty Type:</td>
                                <td>/<?php echo $qnty_type; ?></td>
                            </tr>
                            <tr>
                                <td>Quantity:</td>
                                <td><input type="number" name="qnty" value="1" class="t-inp_box"></td>
                            </tr>
                            <tr>
                                <td>Delivery fee:</td>
                                <td>৳.40</td>
                            </tr>
                            <tr>
                                <td>Delivery Time:</td>
                                <td>30m to 1h</td>
                            </tr>
                            </tbody>
                        </table>
                        <p class="terms-info">
                            By ordering this food you agree with Foodzax's <a href="rules/terms and conditions.php">Terms and Conditions</a> and you agree with our <a href="rules/privacy and policy.php">Privacy Policy</a>
                        </p>
                        <button class="order-confirm-btn">Continue</button>
                    </div>
                    </form>
                </div>
        <?php }?>

      </div>



    <script  src="assets/js/script.js"></script>
</body>
</html>